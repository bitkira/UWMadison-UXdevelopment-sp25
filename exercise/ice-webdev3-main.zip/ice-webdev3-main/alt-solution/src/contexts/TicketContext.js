import { createContext } from "react";

const TicketContext = createContext();
export default TicketContext;