import { createContext } from "react";

const BadgerBudsDataContext = createContext([]);

export default BadgerBudsDataContext;