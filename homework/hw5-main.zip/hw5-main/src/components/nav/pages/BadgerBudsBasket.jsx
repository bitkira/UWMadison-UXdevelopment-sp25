export default function BadgerBudsBasket(props) {
    return <div>
        <h1>Badger Buds Basket</h1>
        <p>These cute cats could be all yours!</p>
    </div>
}